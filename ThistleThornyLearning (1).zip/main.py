def findArea(r):
    PI = 3.142
    return PI * (r*r);
 
# Driver method
print("Area is %.6f" % findArea(5))